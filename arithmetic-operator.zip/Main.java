public class Main
{
	public static void main(String[] args) {
	    int a=10;
	    int b= 20;
	    int c=a + b;
	    int d=a- b;
	    int e=a*b;
	    int f=a/b;
	    
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		
		
		
		
	}
}